import pytesseract
import cv2
from PIL import Image

custom_oem_psm_config = r'--oem 3 --psm 3'
image = Image.open(r'/media/lqnhu/G/Test/OCR/table/1/2.png')

cropped = image.crop((151, 206, 301, 715))
str = pytesseract.image_to_alto_xml(cropped, config=custom_oem_psm_config)
print(str)

cropped1 = image.crop((308, 279, 425, 620))
str1 = pytesseract.image_to_alto_xml(cropped1, config=custom_oem_psm_config)

print(str1)