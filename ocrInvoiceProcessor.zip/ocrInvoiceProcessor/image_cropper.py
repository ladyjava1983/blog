import logging
import os

from PIL import Image

import app_util

logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
configDict = app_util.load_config('ImageCropper')

try:
    folderPath = configDict.get('original-folder')
    cropFolder = configDict.get('crop-folder')
    listFile = os.listdir(folderPath)

    logging.info('Begin crop images for ' + folderPath)

    left = configDict.get('crop-left')
    top = configDict.get('crop-top')
    width = configDict.get('crop-width')
    height = configDict.get('crop-height')

    for fileName in listFile:
        filePath = folderPath + fileName
        image = Image.open(filePath)
        cropped = image.crop((int(left), int(top), int(width), int(height)))
        cropped.save(cropFolder + fileName)

    app_util.remove_duplicate(cropFolder)
    logging.info('Done cropping images for ' + folderPath)
except NameError:
    logging.error('Error while crop images for ' + NameError)
