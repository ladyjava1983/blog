import pandas as pd
import pytesseract as pytesseract
import cv2

import app_util
import logging
import os
from PIL import Image

try:
    configDict = app_util.load_config('OcrReader')
    path_template = configDict.get('template-file')
    path_train = configDict.get('train-file')
    ocr_folder = configDict.get('ocr-folder')
    dicTemplate = pd.read_csv(path_template, index_col=0, header=[1], squeeze=True).to_dict()
    dictTrain = app_util.read_train_data(path_train)
    imageList = os.listdir(ocr_folder)

    for fileName in imageList:
        template_name = str(dicTemplate.get(fileName))
        template_name = template_name.replace('.jpg', '')
        list_field = dictTrain.get(template_name)
        path = ocr_folder + fileName

        if type(list_field) is list:
            for item in list_field:
                field_name = item[0]
                left = item[1]

                if left == left:
                    top = item[2]
                    width = item[3]
                    height = item[4]

                    image = Image.open(path)
                    cropped = image.crop((int(left), int(top), int(width), int(height)))
                    ocr_data = pytesseract.image_to_string(image)
                    print(ocr_data)

except NameError:
    logging.error('Error while read data on image ' + NameError)
