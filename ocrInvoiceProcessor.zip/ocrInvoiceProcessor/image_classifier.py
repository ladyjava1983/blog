import logging
import os

import pandas as pd

import app_util
import find_subimage

logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
configDict = app_util.load_config('ImageClassifier')
result = []

try:
    outputFolder = configDict.get('output-folder')
    trainFolder = configDict.get('train-folder')
    confidence = configDict.get('confidence')

    templateFolder = configDict.get('template-folder')
    templateList = os.listdir(templateFolder)

    imagesFolder = configDict.get('images-folder')
    imageList = os.listdir(imagesFolder)

    logging.info('Begin classifying for ' + imagesFolder)

    for fileName in imageList:
        for templateName in templateList:
            primaryFile = imagesFolder + fileName
            subFile = templateFolder + templateName
            outfile = outputFolder + fileName
            image_locations = find_subimage.find_subimages_from_files(primaryFile,
                                                                      subFile, float(confidence))
            total = len(image_locations)
            if total > 0:
                result.append([fileName, templateName])
                find_subimage.save_output(primaryFile, outfile, image_locations)
                break

        logging.info('Done processing for ' + fileName)

    df = pd.DataFrame(result, columns=['File Name', 'Template Name'])
    df.to_csv(trainFolder + 'classify.csv', index=False, header=True)
    logging.info('Done classifying for ' + imagesFolder)

except NameError:
    logging.error('Error while classify images ' + NameError)
