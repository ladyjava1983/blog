import hashlib
import os
import configparser
import pandas as pd


def remove_duplicate(folderPath):
    list_file = os.listdir(folderPath)
    duplicates = []
    hash_keys = dict()
    for index, filename in enumerate(list_file):
        file_path = folderPath + filename
        if os.path.isfile(file_path):
            with open(file_path, 'rb') as f:
                file_hash = hashlib.md5(f.read()).hexdigest()
            if file_hash not in hash_keys:
                hash_keys[file_hash] = index
            else:
                duplicates.append((index, hash_keys[file_hash]))

    for index in duplicates:
        file_name = list_file[index[0]]
        os.remove(folderPath + file_name)


def load_config(item_name):
    config = configparser.RawConfigParser()
    config.read(r'config/application.properties')
    return dict(config.items(item_name))


def read_train_data(path_train):
    frameTrain = pd.read_csv(path_train, header=[1])

    dictTrain = {}
    for row in frameTrain.values:
        template_name = str(row[0])
        field_name = row[1]
        left = row[2]
        top = row[3]
        width = row[4]
        height = row[5]
        subDict = [field_name, left, top, width, height]

        if template_name not in dictTrain:
            dictTrain[template_name] = [subDict]
        else:
            tempList = dictTrain.get(template_name)
            tempList.append(subDict)
            dictTrain[template_name] = tempList

    return dictTrain
